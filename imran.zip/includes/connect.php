
<?php
$conn = mysqli_connect("localhost", "envogoik_envogoik", "Envogue@3@31", "envogoik_amir") or die('connection failed');
$host = "http://localhost/imran";
// if(!$conn){
//     echo mysqli_errno($conn);
// }

?>